// JS/script.js
window.addEventListener('DOMContentLoaded', function() {
  const pdfList = document.getElementById('pdf-list');

  // Leitura dos arquivos PDF
  fetch('http://localhost:80/CV') // Substitua pela URL da pasta CV
    .then(response => response.text())
    .then(data => {
      const parser = new DOMParser();
      const html = parser.parseFromString(data, 'text/html');
      const links = html.querySelectorAll('a[href$=".pdf"]');

      links.forEach(link => {
        const summary = link.textContent.slice(0, 200) + '...';
        const url = new URL(link.href, 'http://localhost:80');
        url.pathname = '/CV/' + url.pathname.slice(1); // Adiciona a pasta CV ao caminho do arquivo
        const fileURL = url.href;

        const listItem = document.createElement('li');
        const anchor = document.createElement('a');
        anchor.href = fileURL;
        anchor.textContent = summary;
        anchor.target = '_blank'; // Abre em nova aba ou janela

        listItem.appendChild(anchor);
        pdfList.appendChild(listItem);
      });
    })
    .catch(error => {
      console.error('Erro ao ler os arquivos PDF:', error);
    });
});
