const express = require('express');
const app = express();
const fs = require('fs');
const path = require('path');

// Rota para listar os PDFs
app.post('/list-pdf', (req, res) => {
  const { folderPath } = req.body;
  const pdfs = [];

  fs.readdir(folderPath, (err, files) => {
    if (err) {
      console.error('Erro ao ler os arquivos:', err);
      res.status(500).json({ error: 'Erro ao ler os arquivos' });
    } else {
      files.forEach(file => {
        if (path.extname(file) === '.pdf') {
          const filePath = path.join(folderPath, file);
          const fileStat = fs.statSync(filePath);
          const fileSize = Math.ceil(fileStat.size / 1024); // Tamanho em KB
          pdfs.push({ name: file, path: filePath, size: fileSize });
        }
      });

      res.json(pdfs);
    }
  });
});

app.listen(80, () => {
  console.log('Servidor em execução na porta 80');
});
